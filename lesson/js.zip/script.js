let programming = {
   languages: ['Javascript', 'Python', 'Ruby'],
   isChallenging: true,
   isRewarding: true,
   difficulty: 8,
   jokes: 'http://example.com/q/234075/whats-your-best-joke',
}
programming.languages.push('Go');
programming.difficulty = 7;
delete programming.jokes;
programming.isFun = true;